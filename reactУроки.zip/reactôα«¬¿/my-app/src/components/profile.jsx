const Profile = ()=>{
   return(
    <div className='content'>
    <div>
      <img src='https://www.kiprinform.com/wp-content/uploads/2020/05/our-beach.jpg' />
    </div>
    <div>
      <div>
        <img src=' https://bugaga.ru/uploads/posts/2017-03/1489052030_kotik-hosiko-12.jpg' />
       
      </div>
      + description
    </div>
    <div>
      My posts
      <div>
        new posts
      </div>
      <div>
        <div>
          post1
        </div>
        <div>
          post2
        </div>
        <div>
          post3
        </div>
      </div>
    </div>
  </div>
   ) 
}
export default Profile