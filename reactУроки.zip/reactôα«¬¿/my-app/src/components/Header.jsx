const Header = ()=>{
   return(
    <header className='header'>
        <img src='https://flyclipart.com/thumb2/sports-logos-logos-sports-logo-115806.png' />
    </header>
   ) 
}
export default Header