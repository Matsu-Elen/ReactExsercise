
import './App.css';
import Header from './components/Header';
import NavBar from './components/nav';
import Profile from './components/profile';

const App = () => {
  return (
    <div className='app-wrapper'>
      <Header/>
      <NavBar />
      <Profile />
    </div>
  );
}


export default App;
